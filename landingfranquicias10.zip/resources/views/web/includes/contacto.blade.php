

    <section class="pad-contact" id="contacto">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="section-title ">
                        <h3 class="font-contact">Información Personal</h3>


                    </div>
                    <div class="get-free-quote__form-box">
                        <form  action="/action_page.php">

                            <div class="tab">
                              <div class="row">
                               <!--  <div class="col-xl-6 col-lg-6">
                                    <div class="get-free-quote__form-input-box">
                                        <input type="text" placeholder="Nombres" oninput="this.className = ''" name="name" id="name">
                                    </div>
                                </div> -->
                              <!--   <div class="col-xl-6 col-lg-6">
                                    <div class="get-free-quote__form-input-box">
                                        <input type="text" placeholder="Apellidos" oninput="this.className = ''" name="lastname" id="lastname">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-lg-6">
                                    <div class="get-free-quote__form-input-box">
                                        <input type="text" placeholder="DNI" oninput="this.className = ''" name="dni" id="dni">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-lg-6">
                                    <div class="get-free-quote__form-input-box">
                                        <input type="text" placeholder="Celular" oninput="this.className = ''" name="phone" id="phone">
                                    </div>
                                </div>
                                <div class="col-xl-12">
                                   <div class="get-free-quote__form-input-box">
                                    <input type="email" placeholder="Correo" oninput="this.className = ''" name="email" id="email">
                                </div>
                            </div>


                            <div class="col-xl-4 col-lg-4">
                                <div class="get-free-quote__form-input-box">
                                    <input type="text" placeholder="Departamento" oninput="this.className = ''" name="depart" id="depart">
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-4">
                                <div class="get-free-quote__form-input-box">
                                    <input type="text" placeholder="Provincia" oninput="this.className = ''" name="provin" id="provin">
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-4">
                                <div class="get-free-quote__form-input-box">
                                    <input type="text" placeholder="Distrito" oninput="this.className = ''" name="distric" id="distric">
                                </div>
                            </div> -->
                        </div>
                    </div>
                    <style type="">
                        .tab h3{
                                color: #fff; 
                                font-family: 'Inter';
                                font-weight: 600   
                        }
                        
                    </style>
                    <div class="tab">
                              <div class="row">
                                        <div class="row">   
                                                <div class="col-lg-12">
                                        <h3>¿Cuentas con un local?</h3>
                                        <br>    
                                </div>

                                <div class="col-xl-4 col-lg-4">
                                    <div class="get-free-quote__form-input-box">
                                           <input type="checkbox" id="scales" oninput="this.className = ''" name="scales"  /><label for="scales">Propio</label>
                                    </div>
                                </div>
                               
                                <div class="col-xl-4 col-lg-4">
                                    <div class="get-free-quote__form-input-box">
                                           <input type="checkbox" id="scales" oninput="this.className = ''" name="scales"  /><label for="scales">Alquilado</label>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4">
                                    <div class="get-free-quote__form-input-box">
                                           <input type="checkbox" id="scales" oninput="this.className = ''" name="scales"  /><label for="scales">No tengo actualmente</label>
                                    </div>
                                </div>
                                        </div>
                                <!--  -->
                                    <div class="row">
                                            <div class="col-lg-12">
                                        <h3>¿Tienes acceso a internet?</h3>
                                        <br>    
                                </div> 
                                <div class="col-xl-4 col-lg-4">
                                    <div class="get-free-quote__form-input-box">
                                           <input type="checkbox" id="scales" oninput="this.className = ''" name="scales"  /><label for="scales">Si</label>
                                    </div>
                                </div>
                               
                                <div class="col-xl-4 col-lg-4">
                                    <div class="get-free-quote__form-input-box">
                                           <input type="checkbox" id="scales" oninput="this.className = ''" name="scales"  /><label for="scales">No</label>
                                    </div>        
                                    </div>                      
                            <!--  -->
                              <div class="row">
                                    <div class="col-lg-12">
                                        <h3> ¿Cuánto presupuesto de inversión tienes para la implementación de equipos?</h3>
                                        <br>    
                                </div> 
                                <div class="col-xl-4 col-lg-4">
                                    <div class="get-free-quote__form-input-box">
                                           <input type="checkbox" id="scales" oninput="this.className = ''" name="scales"  /><label for="scales">S/0 - S/5,000</label>
                                    </div>
                                </div>
                               
                                <div class="col-xl-4 col-lg-4">
                                    <div class="get-free-quote__form-input-box">
                                           <input type="checkbox" id="scales" oninput="this.className = ''" name="scales"  /><label for="scales">S/5,000 - S/15,000 </label>
                                    </div>   
                                </div>
                                 <div class="col-xl-4 col-lg-4">
                                    <div class="get-free-quote__form-input-box">
                                           <input type="checkbox" id="scales" oninput="this.className = ''" name="scales"  /><label for="scales">S/15,000 - a más</label>
                                    </div>   
                                </div> 
                              </div>
                                <!--  -->
                               <div class="row">    
                                     <div class="col-lg-12">
                                        <h3> ¿Eres una persona jurídica?: Régimen MYPE tributario o apertura nueva RUC - Sunat?</h3>
                                        <br>    
                                </div> 
                                <div class="col-xl-4 col-lg-4">
                                    <div class="get-free-quote__form-input-box">
                                           <input type="checkbox" id="scales" oninput="this.className = ''" name="scales"  /><label for="scales">Si</label>
                                    </div>
                                </div>
                               
                                <div class="col-xl-4 col-lg-4">
                                    <div class="get-free-quote__form-input-box">
                                           <input type="checkbox" id="scales" oninput="this.className = ''" name="scales"  /><label for="scales">No </label>
                                    </div>   
                                </div>
                               </div>
                                
                           
                        </div>
                    </div>
                   <div class="tab">
                              <div class="row">
                                <div class="col-xl-6 col-lg-6">
                                    <div class="get-free-quote__form-input-box">
                                        <input type="image" oninput="this.className = ''" name="name" id="name">
                                    </div>
                                </div>
                              <!--   <div class="col-xl-6 col-lg-6">
                                    <div class="get-free-quote__form-input-box">
                                        <input type="text" placeholder="Apellidos" oninput="this.className = ''" name="lastname" id="lastname">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-lg-6">
                                    <div class="get-free-quote__form-input-box">
                                        <input type="text" placeholder="DNI" oninput="this.className = ''" name="dni" id="dni">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-lg-6">
                                    <div class="get-free-quote__form-input-box">
                                        <input type="text" placeholder="Celular" oninput="this.className = ''" name="phone" id="phone">
                                    </div>
                                </div>
                                <div class="col-xl-12">
                                   <div class="get-free-quote__form-input-box">
                                    <input type="email" placeholder="Correo" oninput="this.className = ''" name="email" id="email">
                                </div>
                            </div>


                            <div class="col-xl-4 col-lg-4">
                                <div class="get-free-quote__form-input-box">
                                    <input type="text" placeholder="Departamento" oninput="this.className = ''" name="depart" id="depart">
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-4">
                                <div class="get-free-quote__form-input-box">
                                    <input type="text" placeholder="Provincia" oninput="this.className = ''" name="provin" id="provin">
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-4">
                                <div class="get-free-quote__form-input-box">
                                    <input type="text" placeholder="Distrito" oninput="this.className = ''" name="distric" id="distric">
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>
                
<br>    <br>    <br>    
                <div style="overflow:auto;">
                    <div style="float:right;">
                      <button type="button" id="prevBtn" onclick="nextPrev(-1)">RETROCEDER</button>
                      <button type="button" id="nextBtn" onclick="nextPrev(1)">QUIERO SER UN PARTNER GANADOR</button>
                  </div>
              </div>
              <!-- Circles which indicates the steps of the form: -->
              <div style="text-align:center;margin-top:40px;">
                <span class="step"></span>
                <span class="step"></span>
                <span class="step"></span>

            </div>
        </form>
        <div class="result"></div>
    </div>
</div>
</div>

</div>
</div>
</section>
<script>
var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
// This function will display the specified tab of the form...
var x = document.getElementsByClassName("tab");
x[n].style.display = "block";
//... and fix the Previous/Next buttons:
if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
} else {
    document.getElementById("prevBtn").style.display = "inline";
}
if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
} else {
    document.getElementById("nextBtn").innerHTML = "QUIERO SER UN PARTNER GANADOR";
}
//... and run a function that will display the correct step indicator:
fixStepIndicator(n)
}

function nextPrev(n) {
// This function will figure out which tab to display
var x = document.getElementsByClassName("tab");
// Exit the function if any field in the current tab is invalid:
if (n == 1 && !validateForm()) return false;
// Hide the current tab:
x[currentTab].style.display = "none";
// Increase or decrease the current tab by 1:
currentTab = currentTab + n;
// if you have reached the end of the form...
if (currentTab >= x.length) {
// ... the form gets submitted:
document.getElementById("regForm").submit();
return false;
}
// Otherwise, display the correct tab:
showTab(currentTab);
}

function validateForm() {
// This function deals with validation of the form fields
var x, y, i, valid = true;
x = document.getElementsByClassName("tab");
y = x[currentTab].getElementsByTagName("input");
// A loop that checks every input field in the current tab:
for (i = 0; i < y.length; i++) {
// If a field is empty...
if (y[i].value == "") {
  // add an "invalid" class to the field:
  y[i].className += " invalid";
  // and set the current valid status to false
  valid = false;
}
}
// If the valid status is true, mark the step as finished and valid:
if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
}
return valid; // return the valid status
}

function fixStepIndicator(n) {
// This function removes the "active" class of all steps...
var i, x = document.getElementsByClassName("step");
for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
}
//... and adds the "active" class on the current step:
x[n].className += " active";
}
</script>