 <!--Site Footer Start-->
       <style type="">
           
           .footer-widget__link-list .list-unstyled li a
           {
            color:; #fff;
           }
           .logo-footer{
            width: 380px
           }
           @media(max-width: 768px)
           {
                .logo-footer{
                    width: 200px
                }
                .footer-widget__link-list {
                    position: relative;
                    display: block;
                    margin-top: -9px;
                    text-align: center;
                }
                .ico-footer, .ico-footer2{
                    display: none;
                }
                .site-footer {
                    position: relative;
                    display: block;
                    background-color: #192419;
                    text-align: center;
                    z-index: 1;
                }
                .footer-widget__link-list li a {
                    position: relative;
                    display: inline-block;
                    color: #fff;
                    font-size: 14px;
                    font-weight: 100;
                    -webkit-transition: all 500ms ease;
                    transition: all 500ms ease;
                }
           }
       </style>


        <footer class="site-footer">
            <div class="site-footer__bg">
            </div>
            <div class="site-footer__top">
                <div class="pad-container">
                    <div class="row">
                        <div class="col-xl-4 col-lg-4 col-md- wow fadeInUp" data-wow-delay="100ms">
                            <div class="footer-widget__column footer-widget__about">
                                <div class="footer-widget__logo">
                                    <a href="https://kingtech.pe"><img src="https://kingtech.pe/assets/king-blanco.png" class="logo-footer" alt=""></a>
                                </div>
                           
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-6  wow fadeInUp" data-wow-delay="200ms">
                            <div class="footer-widget__column footer-widget__link">
                                <div class="footer-widget__title-box">
                                    <h3 class="footer-widget__title">Contáctanos</h3>
                                </div>
                                <ul class="footer-widget__link-list list-unstyled">
                                    <li><a href="#"><img src="assets/images/ico-whatsapp.png" class="ico-footer"> +51 913 069 000</a></li> 
                                    <li><a href="#"><img src="assets/images/message.png" class="ico-footer"> info@kingtech.pe</a></li>
                                    <li><a href="#"><img src="assets/images/locator.png" class="ico-footer2"> Av. Gral. Antonio Alvarez de <br>  Arenales 2531. Lince</a></li>
                                    
                                </ul>
                            </div>
                        </div>
                         <div class="col-xl-3 col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="200ms">
                            <div class="footer-widget__column footer-widget__link">
                                <div class="footer-widget__title-box">
                                    <h3 class="footer-widget__title">Secciones</h3>
                                </div>
                                <ul class="footer-widget__link-list list-unstyled">
                              
                                    <li><a href="#">Nosotros</a></li>
                                    <li><a href="#productos">Productos</a></li>
                                    <li><a href="#requerimientos">Requerimientos</a></li>
                                      <li><a href="#trabajo">Trabajo</a></li>
                                        <li><a href="#testimonios">Testimonios</a></li>
                                    
                                </ul>
                            </div>
                        </div>
                      
                   
                    </div>
                </div>
            </div>
            <div class="site-footer__bottom">
                <div class="site-footer__bottom-shape"
                    style=""></div>
                <div class="pad-container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="site-footer__bottom-inner">
                                <p class="site-footer__bottom-text">© Copyright 2023<a href="https://kingtech.pe"> KINGTECH</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--Site Footer End--> <?php /**PATH C:\xampp\htdocs\landingfranquicias\resources\views/web/includes/footer.blade.php ENDPATH**/ ?>