<div class="display-carousel-web">
  <img src="assets/images/bannercontactoletras.png">
  <!--Page Header End-->
</div>

<div class="display-carousel-mobile">
  <img src="assets/images/bannercontactomobile.png">
  <!--Page Header End-->
</div>



<section class="pad-contact" id="contacto">
    <div class="pad-container">
        <div class="row">
            <div class="col-xl-12">
                <div class="section-title ">
                    <h3 class="font-contact">Información Personal</h3>


                </div>
                <div class="get-free-quote__form-box">
                    <form action=""
                    class="get-free-quote__form contact-form-validated" novalidate="novalidate">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6">
                            <div class="get-free-quote__form-input-box">
                                <input type="text" placeholder="Nombres" name="name" id="name">
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-6">
                            <div class="get-free-quote__form-input-box">
                                <input type="text" placeholder="Apellidos" name="lastname" id="lastname">
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-6">
                            <div class="get-free-quote__form-input-box">
                                <input type="text" placeholder="DNI" name="dni" id="dni">
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-6">
                            <div class="get-free-quote__form-input-box">
                                <input type="text" placeholder="Celular" name="phone" id="phone">
                            </div>
                        </div>
                        <div class="col-xl-12">
                           <div class="get-free-quote__form-input-box">
                            <input type="email" placeholder="Correo" name="email" id="email">
                        </div>
                    </div>


                    <div class="col-xl-4 col-lg-4">
                        <div class="get-free-quote__form-input-box">
                            <input type="text" placeholder="Departamento" name="depart" id="depart">
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4">
                        <div class="get-free-quote__form-input-box">
                            <input type="text" placeholder="Provincia" name="provin" id="provin">
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4">
                        <div class="get-free-quote__form-input-box">
                            <input type="text" placeholder="Distrito" name="distric" id="distric">
                        </div>
                    </div>
                </div>
                <br>    <br>    
                <div class="row">
                    <div class="col-xl-12 text-center">


                        <button type="submit" class="thm-btn pad-bottom get-free-quote__form-btn">QUIERO SER UN PARTNER GANADOR</button>
                    </div>
                </div>
            </div>
        </form>
        <div class="result"></div>
    </div>
</div>
</div>

</div>
</div>
</section>