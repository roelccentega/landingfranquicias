  <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->

        <section class="main-slider display-carousel-web">
            <div class="main-slider__carousel owl-carousel owl-theme thm-owl__carousel"
                data-owl-options='{"loop": true, "items": 1, "navText": ["<span class=\"icon-left-arrow\"></span>","<span class=\"icon-right-arrow\"></span>"], "margin": 0, "dots": true, "nav": true, "animateOut": "slideOutDown", "animateIn": "fadeIn", "active": true, "smartSpeed": 1000, "autoplay": true, "autoplayTimeout": 7000, "autoplayHoverPause": false}'>

                <div class="item main-slider__slide-1 ">
                    <a href="#contacto">
                    <div class="main-slider__bg "
                        style="background-image: url(assets/images/bannerkingtech.png);">
                    </div>
                    </a>
                    
                   

                    <div class="container">
                        <div class="main-slider__content">
                            <p class="main-slider__sub-title">Franquicias Kingtech</p>
                            <h2 class="main-slider__title">Franquicias Kingtech</h2>
                            <div class="main-slider__btn-box">
                                <a href="#contacto" class="main-slider__btn thm-btn thml-buttom" style="color: transparent;">Ver más</a>
                            </div>
                        </div>
                    </div>
                </div> 

              <div class="item main-slider__slide-2 ">
                    <a href="#contacto">
                    <div class="main-slider__bg"
                        style="background-image: url(assets/images/web4.png);">
                    </div>
                   
                    <div class="container">
                        <div class="main-slider__content">
                            <p class="main-slider__sub-title">Franquicias Kingtech</p>
                            <h2 class="main-slider__title">Franquicias Kingtech</h2>
                            <div class="main-slider__btn-box">
                                <a href="#contacto" class="main-slider__btn thm-btn thml-buttom" style="color: transparent;">Ver más</a>
                            </div>
                        </div>
                    </div>
                    </a>
                </div> 
 
                 <div class="item main-slider__slide-3 ">
                    <a href="#contacto">
                    <div class="main-slider__bg"
                        style="background-image: url(assets/images/web5.png);">
                    </div>
                        </a>
                    <div class="container">
                        <div class="main-slider__content">
                         
                                    <p class="main-slider__sub-title">Franquicias Kingtech</p>
                         
                                 <h2 class="main-slider__title">Franquicias Kingtech</h2>   
                         
                            
                            
                            <div class="main-slider__btn-box">
                                <a href="#contacto" class="main-slider__btn thm-btn thml-buttom" style="color: transparent;">Ver más</a>
                            </div>
                        </div>
                    </div>
                </div> 

            </div>
        </section>
             <section class="main-slider display-carousel-web display-carousel-mobile">
            <div class="main-slider__carousel owl-carousel owl-theme thm-owl__carousel"
                data-owl-options='{"loop": true, "items": 1, "navText": ["<span class=\"icon-left-arrow\"></span>","<span class=\"icon-right-arrow\"></span>"], "margin": 0, "dots": true, "nav": true, "animateOut": "slideOutDown", "animateIn": "fadeIn", "active": true, "smartSpeed": 1000, "autoplay": true, "autoplayTimeout": 7000, "autoplayHoverPause": false}'>

                <div class="item main-slider__slide-1 ">
                    <a href="#contacto">
                    <div class="main-slider__bg "
                        style="background-image: url(assets/images/mobile1.png);">
                    </div>
                </a>
                   

                    <div class="container">
                        <div class="main-slider__content">

                            <p class="main-slider__sub-title">Franquicias Kingtech</p>
                            <h2 class="main-slider__title">Franquicias Kingtech</h2>
                            <div class="main-slider__btn-box">
                                <a href="#contacto" class="main-slider__btn thm-btn thml-buttom" style="color: transparent;">Ver más</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="item main-slider__slide-2 ">
                    <a href="#contacto">
                    <div class="main-slider__bg"
                        style="background-image: url(assets/images/mobile2.png);">
                    </div>
                </a>
                    <div class="container">
                        <div class="main-slider__content">
                            <p class="main-slider__sub-title">Franquicias Kingtech</p>
                            <h2 class="main-slider__title">Franquicias Kingtechg</h2>
                            <div class="main-slider__btn-box">
                                <a href="#contacto" class="main-slider__btn thm-btn thml-buttom" style="color: transparent;">Ver más</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="item main-slider__slide-3 ">
                    <a href="#contacto">
                    <div class="main-slider__bg"
                        style="background-image: url(assets/images/mobile3.png);">
                    </div>
                </a>
                    <div class="container">
                        <div class="main-slider__content">
                            <p class="main-slider__sub-title">Franquicias Kingtech</p>
                            <h2 class="main-slider__title">Franquicias Kingtech</h2>
                            <div class="main-slider__btn-box">
                                <a href="#contacto" class="main-slider__btn thml-buttom" style="color: transparent;">Ver más</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>
