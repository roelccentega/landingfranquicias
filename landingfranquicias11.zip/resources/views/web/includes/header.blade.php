  <style type="text/css">
      .main-menu__btn {
    background-color: #36BA01;
    color: var(--gardon-white);
}
  </style>

  <header class="main-header">
            
            <nav class="main-menu">
                <div class="main-menu__wrapper">
                    <div class="main-menu__wrapper-inner">
                        <div class="main-menu__left">
                            <div class="main-menu__logo">
                                <a href="{{url('/')}}"><img src="https://kingtech.pe/assets/king-blanco.png" width="200px" alt=""></a>
                              
                            </div>
                            <div class="main-menu__main-menu-box">
                                <a href="#" class="mobile-nav__toggler"><i class="fa fa-bars"></i></a>
                                <ul class="main-menu__list">
                                    <li class="dropdown current megamenu">
                                        <a href="#productos">PRODUCTOS </a>
                                        
                                    </li>
                                    <li>
                                        <a href="#requerimientos">REQUERIMIENTOS</a>
                                    </li>
                                  
                                    <li>
                                        <a href="#trabajo">TRABAJO</a>
                                    </li>

                                    <li>
                                        <a href="#testimonios">TESTIMONIOS</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="main-menu__right">
                            <div class="main-menu__btn-box">
                                <a href="{{url('/contacto')}}" class="thm-btn main-menu__btn">CONTÁCTENOS</a>
                            </div>
                           
                        </div>
                    </div>
                </div>
            </nav>
        </header>